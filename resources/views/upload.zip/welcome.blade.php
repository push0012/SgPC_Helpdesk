<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>තොරතුරු කේන්ද්‍රය</title>  
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet" type="text/css">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" ></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet" type="text/css">
    
    <link rel="icon" type="image/png" href="{{ asset('image/sg_info.png') }}" />
    <link rel="stylesheet" href="css/fontawesome/css/all.css">
    
    <link rel="stylesheet" href="https://cdn.metroui.org.ua/v4/css/metro-all.min.css">
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="https://cdn.metroui.org.ua/v4/js/metro.min.js"></script>
    <!-- Fonts -->
    
    <link href="{{ asset('css/style1.css') }}" rel="stylesheet"> 
    <style>
    html, body {
        background-color: #fff;
        color: #636b6f;
        font-family: 'Nunito', sans-serif;
        font-weight: 200;
        height: 100vh;
        margin: 0;
    }

    .full-height {
        height: 100vh;
    }

    .flex-center {
        align-items: center;
        display: flex;
        justify-content: center;
    }

    .position-ref {
        position: relative;
    }

    .top-right {
        position: absolute;
        right: 10px;
        top: 18px;
    }

    .content {
        text-align: center;
    }

    .title {
        font-size: 84px;
    }

    .links > a {
        color: #636b6f;
        padding: 0 25px;
        font-size: 13px;
        font-weight: 600;
        letter-spacing: .1rem;
        text-decoration: none;
        text-transform: uppercase;
    }

    .m-b-md {
        margin-bottom: 30px;
    }
</style>
</head>
<body>
    
    <header>
        <div class="container">
            <div class="row justify-content-center">
                <a href="{{ url('/') }}">
                    <img src="{{ asset('image/head.png') }}" class="responsives" style="height: 150px; align:center;">
                </a>
            </div>
        </div>
    </header>
    <div class="flex-center position-ref full-height">
        @if (Route::has('login'))
        <div class="top-right links">
            @auth
            <a href="{{ url('/home') }}">Home</a>
            @else
            <a href="{{ route('login') }}">Login</a>

            @if (Route::has('register'))
            <a href="{{ route('register') }}">Register</a>
            @endif
            @endauth
        </div>
        @endif

        <div class="content" align="center">
            <div class="containers" >
                <a href="{{ url('/business')}}" class="img1 box bg-info">ව්‍යාපාර</a>
                <a href="{{ url('/human_reso')}}" class="img2 box bg-info">මානව සම්පත</a>
                
            </div>  
        </div>
        
    </div>
    <footer class="footer">
        <div class="container" >
           <div class="row link_info justify-content-center">
              <div class="col-md-2 col-sm-12">
                 <h4>Contact Us</h4>
                 <h5 style="padding-left:5%; padding-top:18%">
                    <li style="font-size:1em; margin-left: 0px;">045-22XXXXX</li>
                </h5>
            </div>
            <div class="vl"></div>
            <div class="col-md-3 col-sm-12">
             <h4>Important Links</h4>

             <li style="margin-left:10%;">Government Information Center</li>
             <li style="margin-left:10%;">Sabaragamu Web Portal</li>

         </div>
         <div class="vl"></div>
         <div class="col-md-3 col-sm-12">
             <h4>Social Media</h4>
             <ul style="list-style-type: none; margin-top:10%; display: inline">
                <li style="padding-right:15%;"><i class="fab fa-facebook fa-3x"></i></li>
                <li style="padding-right:15%;"><i class="fab fa-linkedin fa-3x"></i></li>
                <li><i class="fab fa-twitter fa-3x"></i></li>
            </ul>
        </div>
        <div class="vl"></div>
        <div class="col-md-3 col-sm-12">
         <h4>Online Users</h4>
         <img style="padding-left:15%; " src="/svg/user_count.png"/>
     </div>
 </div>
</div> 
<div class="copyright">
    <div class="container">
        <div class="row justify-content-center align-items-center">
            <span> 
                All rights reserved © 2018 Office of the Deputy Chief Secretary (Planning), Sabaragamuwa Province.
            </span>
        </div>
    </div>
</div>
</footer>
</body>
</html>
