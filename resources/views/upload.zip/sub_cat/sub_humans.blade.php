@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
    <h3>මානව සම්පත</h3>    
    </div>
    <div class="row justify-content-center">
        <div class="containers">
            <a href="{{ url('/job_list')}}" class="img4 box bg-info">රැකියා අවස්ථා</a>
            <a href="{{ url('/training_list')}}" class="img5 box bg-info">පුහුණු අවස්ථා</a>
            <a href="{{ url('/stu_regi')}}" class="img6 box bg-info">ලියාපදිංචි වීම්</a>
        </div>
    </div>
</div>
@endsection