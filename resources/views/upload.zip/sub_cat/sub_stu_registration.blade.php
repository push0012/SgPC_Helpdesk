@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row ">
    <h3>ලියාපදිංචි වීම්</h3>    
    </div>
    <div class="row justify-content-center align-items-center" >
        <div class="containers" align="center">
            <a href="{{ url('/graduate_ins')}}" class="img7 box bg-info">උපාධිධාරීන්</a>
            <a href="{{ url('/diploma_ins')}}" class="img8 box bg-info">ඩිප්ලෝමාධාරීන්</a>
            <a href="{{ url('/stu_regi')}}" class="img9 box bg-info">NVQ සහතිකපත්ලාභීන්</a>
            <a href="{{ url('/stu_regi')}}" class="img10 box bg-info">නුපුහුණු</a>
        </div>
    </div>
</div>
@endsection