@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
    <h3>ව්‍යාපාර කාණ්ඩය</h3>    
    </div>
    <div class="row justify-content-center">
                <div class="containers">
                    <a href="{{ url('/business_list')}}" class="imgs1 box bg-info">කෘෂිකාර්මික 20</a>
                    <a href="" class="imgs2 box bg-info">මුූද්‍රණ 15</a>
                    
                    <a href="" class="imgs3 box bg-info">සංන්නිවේදන 2</a>
                    <a href="" class="imgs4 box bg-info">ඹෟෂධ 15</a>
                    <a href="" class="imgs5 box bg-info">නීති උපදෙස් 5</a>

                    <a href="{{ url('/business_ins')}}" class="imgs6 box bg-warning">ව්‍යාපාර ලියාපදිංචිය</a>
                </div>
                
    </div>
</div>
@endsection