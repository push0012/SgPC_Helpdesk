<?php /* C:\projects\helpdesk\resources\views/main_dashboard.blade.php */ ?>
<?php $__env->startSection('dashboard'); ?>
<div class="container">
        <div class="row">
        <div class="content" align="center">
            <div class="containers" >
                <a href="<?php echo e(url('/business')); ?>" class="img1 box bg-info">ව්‍යාපාර</a>
                <a href="<?php echo e(url('/human_reso')); ?>" class="img2 box bg-info">මානව සම්පත</a>
            </div>  
        </div>
        </div>
        </div>
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>