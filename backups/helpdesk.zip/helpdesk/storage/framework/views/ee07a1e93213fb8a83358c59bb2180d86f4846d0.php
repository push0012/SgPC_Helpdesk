<?php /* C:\projects\helpdesk\resources\views/footer.blade.php */ ?>

  <div class="footer container-fluid">
  <div class="col-md-12" >
   <div class="row link_info justify-content-center bg-white" style=" height: 350px; color: white; padding-top: 0;">

    <div class="col-md-3 col-sm-12 footer-bar" style="background-color:#000000;">
     <h4>Contact Us</h4>
     <h5 style="padding-left:5%; padding-top:10%;">
     <span style="font-size:1.9em; margin-left: 0px;">045-22XXXXX</span>
    </h5>
    </div>
  <div class="col-md-3 col-sm-12 footer-bar" style="background-color:#000000;">
   <h4>Important Links</h4>
   <li style="line-height:3">Government Information Center</li>
   <li style="">Sabaragamu Web Portal</li>
 </div>
 <div class="col-md-3 col-sm-12 footer-bar" style="background-color:#000000;">
   <h4>Social Media</h4>
   <ul style="list-style-type: none; margin-top:10%; display: inline">
    <li style="padding-right:15%;"><i class="fab fa-facebook fa-3x"></i></li>
    <li style="padding-right:15%;"><i class="fab fa-linkedin fa-3x"></i></li>
    <li><i class="fab fa-twitter fa-3x"></i></li>
  </ul>
</div>
<div class="col-md-3 col-sm-12 footer-bar" style="background-color:#000000;">
 <h4>Online Users</h4>
 <img style="padding-left:15%; " src="/image/user_count.png"/>
</div>
</div>
</div> </div> 

<div class="copyright" >
  <div class="container" style="border-top: 1px solid #636363; padding-top:3px;">
    <div class="row justify-content-center " >
      <span> 
        All rights reserved © 2019 Office of the Deputy Chief Secretary (Planning), Sabaragamuwa Provincial Council.
       Design & Developed by <a href="https://www.linkedin.com" target="_blanck" style="color: white !important;"><u>Pushpamal Gunasena</u></a>
</span>
    </div>
  </div>
</div>
