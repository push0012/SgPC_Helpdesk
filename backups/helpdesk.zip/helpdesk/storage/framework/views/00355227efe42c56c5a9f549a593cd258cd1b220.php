<?php /* C:\projects\helpdesk\resources\views/sub_cat/sub_stu_registration.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row ">
        <h3>ලියාපදිංචි වීම</h3>    
    </div>
    <hr>
    <div class="row justify-content-center align-items-center" >
        <div class="containers" align="center">
            <a href="<?php echo e(url('/graduate_ins')); ?>" class="img7 box bg-warning">
                <div class="row">
                    <div class="col-md-4">
                        <img  src="<?php echo e(asset('image/graduate.png')); ?>" style="border-radius: 18px; width: 100px; height: 100px; ">
                    </div>
                    <div class="col-md-8">
                        <h5 class="box-head">උපාධිධාරීන්</h5>
                        <span></span>
                        <img  src="<?php echo e(asset('image/go.png')); ?>" class="bottomright" style="width: 35px; height: 35px;">
                    </div>
                </div>
            </a>
            <a href="<?php echo e(url('/diploma_ins')); ?>" class="img8 box bg-warning">
                <div class="row">
                    <div class="col-md-4">
                        <img  src="<?php echo e(asset('image/diploma.png')); ?>" style="border-radius: 18px; width: 100px; height: 100px; ">
                    </div>
                    <div class="col-md-8">
                        <h5 class="box-head">ඩිප්ලෝමාධාරීන්</h5>
                        <span></span>
                        <img  src="<?php echo e(asset('image/go.png')); ?>" class="bottomright" style="width: 35px; height: 35px;">
                    </div>
                </div>
            </a>
            <a href="<?php echo e(url('/stu_regi')); ?>" class="img9 box bg-warning">
                <div class="row">
                    <div class="col-md-4">
                        <img  src="<?php echo e(asset('image/nvq.png')); ?>" style="border-radius: 18px; width: 100px; height: 100px; ">
                    </div>
                    <div class="col-md-8">
                        <h5 class="box-head">NVQ සහතිකපත්ලාභීන්</h5>
                        <span></span>
                        <img  src="<?php echo e(asset('image/go.png')); ?>" class="bottomright" style="width: 35px; height: 35px;">
                    </div>
                </div>
            </a>
            <a href="<?php echo e(url('/stu_regi')); ?>" class="img10 box bg-warning">
                <div class="row">
                    <div class="col-md-4">
                        <img  src="<?php echo e(asset('image/untrained.png')); ?>" style="border-radius: 18px; width: 100px; height: 100px; ">
                    </div>
                    <div class="col-md-8">
                        <h5 class="box-head">නුපුහුණු</h5>
                        <span></span>
                        <img  src="<?php echo e(asset('image/go.png')); ?>" class="bottomright" style="width: 35px; height: 35px;">
                    </div>
                </div>
            </a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>