<?php /* C:\projects\helpdesk\resources\views/dashboard.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="containers">
    <div class="img1 box bg-info">ව්‍යාපාර ලියාපදිංචිය</div>
    <div class="img2 box bg-danger">මානව සම්පත</div>
    <div class="img3 box bg-warning">අධ්‍යාපන</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>