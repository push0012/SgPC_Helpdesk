<div class="left-area">
<h4 align="center" style="">Content</h4>
<div id="accordion1">
    <h5 class="mb-0">
        <button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
            මානව සම්පත
        </button>
    </h5>
    <div id="collapseOne" class="collapse " aria-labelledby="headingOne" data-parent="#accordion1">
        <div class="card-body">
            <h6>රැකියා අවස්ථා</h6>
            <h6>පුහුණු අවස්ථා</h6>
            <h6>ලියාපදිංචි වීම්</h6>
        </div>
    </div> 
</div>
<div id="accordion2">
    <h5 class="mb-0">
        <button width="100%" class="btn btn-link" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseOne">
            මාර්ගෝපදේශනය
        </button>
    </h5>
    <div id="collapseTwo" class="collapse " aria-labelledby="headingOne" data-parent="#accordion2">
        <div class="card-body">
            <h6>රැකියා අවස්ථා</h6>
            <h6>පුහුණු අවස්ථා</h6>
            <h6>ලියාපදිංචි වීම්</h6>
        </div>
    </div> 
</div>
<div id="accordion3">
    <h5 class="mb-0">
        <button class="btn btn-link" data-toggle="collapse" data-target="#collapseThree" aria-expanded="true" aria-controls="collapseOne">
            ව්‍යාසායකත්වය
        </button>
    </h5>
    <div id="collapseThree" class="collapse " aria-labelledby="headingOne" data-parent="#accordion3">
        <div class="card-body">
            <h6>කෘෂිකාර්මික</h6>
            <h6>මුූද්‍රණ</h6>
            <h6>සංන්නිවේදන</h6>
            <h6>ඹෟෂධ</h6>
            <h6>නීති උපදෙස්</h6>
            <h6>ව්‍යාපාර ලියාපදිංචිය</h6>
        </div>
    </div> 
</div>
</div>